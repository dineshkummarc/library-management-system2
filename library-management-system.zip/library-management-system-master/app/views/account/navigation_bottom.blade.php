<div class="footer">
	<div class="container">
		<b class="copyright">&copy; {{ date('Y') }} - Automated Library Management System </b> All rights reserved.
		<br><a href="https://github.com/prabhakar267/library-management-system" target="_blank">Fork on Github</a>
	</div>
</div>
